﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class backup
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(backup))
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.cancel1 = New System.Windows.Forms.Button()
        Me.backup_CSV = New System.Windows.Forms.Button()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Panel1.Controls.Add(Me.cancel1)
        Me.Panel1.Controls.Add(Me.backup_CSV)
        Me.Panel1.Location = New System.Drawing.Point(97, 41)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(608, 355)
        Me.Panel1.TabIndex = 10
        '
        'cancel1
        '
        Me.cancel1.BackColor = System.Drawing.Color.PaleVioletRed
        Me.cancel1.BackgroundImage = CType(resources.GetObject("cancel1.BackgroundImage"), System.Drawing.Image)
        Me.cancel1.Font = New System.Drawing.Font("Century Gothic", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cancel1.ForeColor = System.Drawing.SystemColors.HighlightText
        Me.cancel1.Location = New System.Drawing.Point(235, 213)
        Me.cancel1.Name = "cancel1"
        Me.cancel1.Size = New System.Drawing.Size(135, 41)
        Me.cancel1.TabIndex = 8
        Me.cancel1.Text = "Cancel"
        Me.cancel1.UseVisualStyleBackColor = False
        '
        'backup_CSV
        '
        Me.backup_CSV.BackColor = System.Drawing.Color.PaleVioletRed
        Me.backup_CSV.BackgroundImage = CType(resources.GetObject("backup_CSV.BackgroundImage"), System.Drawing.Image)
        Me.backup_CSV.Font = New System.Drawing.Font("Century Gothic", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.backup_CSV.ForeColor = System.Drawing.SystemColors.HighlightText
        Me.backup_CSV.Location = New System.Drawing.Point(180, 97)
        Me.backup_CSV.Name = "backup_CSV"
        Me.backup_CSV.Size = New System.Drawing.Size(236, 87)
        Me.backup_CSV.TabIndex = 7
        Me.backup_CSV.Text = "Backup CSV File"
        Me.backup_CSV.UseVisualStyleBackColor = False
        '
        'backup
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.Panel1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
        Me.Name = "backup"
        Me.Text = "BACKUP"
        Me.Panel1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Panel1 As Panel
    Friend WithEvents cancel1 As Button
    Friend WithEvents backup_CSV As Button
End Class
