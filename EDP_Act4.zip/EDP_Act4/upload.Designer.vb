﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class upload
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(upload))
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.BackgroundWorker1 = New System.ComponentModel.BackgroundWorker()
        Me.upload_CSV = New System.Windows.Forms.Button()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.cancel1 = New System.Windows.Forms.Button()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'DataGridView1
        '
        Me.DataGridView1.BackgroundColor = System.Drawing.Color.Thistle
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.GridColor = System.Drawing.SystemColors.HighlightText
        Me.DataGridView1.Location = New System.Drawing.Point(91, 38)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.Size = New System.Drawing.Size(431, 231)
        Me.DataGridView1.TabIndex = 0
        '
        'upload_CSV
        '
        Me.upload_CSV.BackColor = System.Drawing.Color.Transparent
        Me.upload_CSV.BackgroundImage = CType(resources.GetObject("upload_CSV.BackgroundImage"), System.Drawing.Image)
        Me.upload_CSV.Font = New System.Drawing.Font("Century Gothic", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.upload_CSV.ForeColor = System.Drawing.SystemColors.HighlightText
        Me.upload_CSV.Location = New System.Drawing.Point(198, 284)
        Me.upload_CSV.Name = "upload_CSV"
        Me.upload_CSV.Size = New System.Drawing.Size(183, 41)
        Me.upload_CSV.TabIndex = 7
        Me.upload_CSV.Text = "Upload CSV File"
        Me.upload_CSV.UseVisualStyleBackColor = False
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Panel1.Controls.Add(Me.cancel1)
        Me.Panel1.Controls.Add(Me.upload_CSV)
        Me.Panel1.Controls.Add(Me.DataGridView1)
        Me.Panel1.Location = New System.Drawing.Point(84, 42)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(608, 355)
        Me.Panel1.TabIndex = 9
        '
        'cancel1
        '
        Me.cancel1.BackColor = System.Drawing.Color.PaleVioletRed
        Me.cancel1.BackgroundImage = CType(resources.GetObject("cancel1.BackgroundImage"), System.Drawing.Image)
        Me.cancel1.Font = New System.Drawing.Font("Century Gothic", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cancel1.ForeColor = System.Drawing.SystemColors.HighlightText
        Me.cancel1.Location = New System.Drawing.Point(387, 284)
        Me.cancel1.Name = "cancel1"
        Me.cancel1.Size = New System.Drawing.Size(135, 41)
        Me.cancel1.TabIndex = 8
        Me.cancel1.Text = "Cancel"
        Me.cancel1.UseVisualStyleBackColor = False
        '
        'upload
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(10.0!, 21.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(775, 462)
        Me.Controls.Add(Me.Panel1)
        Me.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
        Me.Margin = New System.Windows.Forms.Padding(5)
        Me.Name = "upload"
        Me.Text = "UPLOAD"
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents BackgroundWorker1 As System.ComponentModel.BackgroundWorker
    Friend WithEvents upload_CSV As Button
    Friend WithEvents Panel1 As Panel
    Friend WithEvents cancel1 As Button
End Class
