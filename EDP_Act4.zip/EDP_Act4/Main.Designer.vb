﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Main
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Main))
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.add_customers = New System.Windows.Forms.Button()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.view_subs = New System.Windows.Forms.Button()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.delete_customers = New System.Windows.Forms.Button()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.view_reviews = New System.Windows.Forms.Button()
        Me.Panel5 = New System.Windows.Forms.Panel()
        Me.upload_button = New System.Windows.Forms.Button()
        Me.Panel6 = New System.Windows.Forms.Panel()
        Me.backup_button = New System.Windows.Forms.Button()
        Me.Panel1.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.Panel3.SuspendLayout()
        Me.Panel4.SuspendLayout()
        Me.Panel5.SuspendLayout()
        Me.Panel6.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Panel1.Controls.Add(Me.add_customers)
        Me.Panel1.Location = New System.Drawing.Point(58, 58)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(236, 79)
        Me.Panel1.TabIndex = 8
        '
        'add_customers
        '
        Me.add_customers.BackColor = System.Drawing.Color.PaleVioletRed
        Me.add_customers.BackgroundImage = CType(resources.GetObject("add_customers.BackgroundImage"), System.Drawing.Image)
        Me.add_customers.Font = New System.Drawing.Font("Century Gothic", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.add_customers.ForeColor = System.Drawing.SystemColors.HighlightText
        Me.add_customers.Location = New System.Drawing.Point(26, 17)
        Me.add_customers.Name = "add_customers"
        Me.add_customers.Size = New System.Drawing.Size(183, 41)
        Me.add_customers.TabIndex = 6
        Me.add_customers.Text = "Add Customers"
        Me.add_customers.UseVisualStyleBackColor = False
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Panel2.Controls.Add(Me.view_subs)
        Me.Panel2.Location = New System.Drawing.Point(58, 171)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(236, 79)
        Me.Panel2.TabIndex = 9
        '
        'view_subs
        '
        Me.view_subs.BackColor = System.Drawing.Color.PaleVioletRed
        Me.view_subs.BackgroundImage = CType(resources.GetObject("view_subs.BackgroundImage"), System.Drawing.Image)
        Me.view_subs.Font = New System.Drawing.Font("Century Gothic", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.view_subs.ForeColor = System.Drawing.SystemColors.HighlightText
        Me.view_subs.Location = New System.Drawing.Point(26, 18)
        Me.view_subs.Name = "view_subs"
        Me.view_subs.Size = New System.Drawing.Size(183, 41)
        Me.view_subs.TabIndex = 6
        Me.view_subs.Text = "View Subscriptions"
        Me.view_subs.UseVisualStyleBackColor = False
        '
        'Panel3
        '
        Me.Panel3.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Panel3.Controls.Add(Me.delete_customers)
        Me.Panel3.Location = New System.Drawing.Point(402, 58)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(236, 79)
        Me.Panel3.TabIndex = 10
        '
        'delete_customers
        '
        Me.delete_customers.BackColor = System.Drawing.Color.PaleVioletRed
        Me.delete_customers.BackgroundImage = CType(resources.GetObject("delete_customers.BackgroundImage"), System.Drawing.Image)
        Me.delete_customers.Font = New System.Drawing.Font("Century Gothic", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.delete_customers.ForeColor = System.Drawing.SystemColors.HighlightText
        Me.delete_customers.Location = New System.Drawing.Point(31, 17)
        Me.delete_customers.Name = "delete_customers"
        Me.delete_customers.Size = New System.Drawing.Size(183, 41)
        Me.delete_customers.TabIndex = 6
        Me.delete_customers.Text = "Delete Customers"
        Me.delete_customers.UseVisualStyleBackColor = False
        '
        'Panel4
        '
        Me.Panel4.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Panel4.Controls.Add(Me.view_reviews)
        Me.Panel4.Location = New System.Drawing.Point(402, 171)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(236, 79)
        Me.Panel4.TabIndex = 11
        '
        'view_reviews
        '
        Me.view_reviews.BackColor = System.Drawing.Color.PaleVioletRed
        Me.view_reviews.BackgroundImage = CType(resources.GetObject("view_reviews.BackgroundImage"), System.Drawing.Image)
        Me.view_reviews.Font = New System.Drawing.Font("Century Gothic", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.view_reviews.ForeColor = System.Drawing.SystemColors.HighlightText
        Me.view_reviews.Location = New System.Drawing.Point(31, 18)
        Me.view_reviews.Name = "view_reviews"
        Me.view_reviews.Size = New System.Drawing.Size(183, 41)
        Me.view_reviews.TabIndex = 6
        Me.view_reviews.Text = "View Reviews"
        Me.view_reviews.UseVisualStyleBackColor = False
        '
        'Panel5
        '
        Me.Panel5.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Panel5.Controls.Add(Me.upload_button)
        Me.Panel5.Location = New System.Drawing.Point(58, 284)
        Me.Panel5.Name = "Panel5"
        Me.Panel5.Size = New System.Drawing.Size(236, 79)
        Me.Panel5.TabIndex = 12
        '
        'upload_button
        '
        Me.upload_button.BackColor = System.Drawing.Color.PaleVioletRed
        Me.upload_button.BackgroundImage = CType(resources.GetObject("upload_button.BackgroundImage"), System.Drawing.Image)
        Me.upload_button.Font = New System.Drawing.Font("Century Gothic", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.upload_button.ForeColor = System.Drawing.SystemColors.HighlightText
        Me.upload_button.Location = New System.Drawing.Point(31, 18)
        Me.upload_button.Name = "upload_button"
        Me.upload_button.Size = New System.Drawing.Size(183, 41)
        Me.upload_button.TabIndex = 6
        Me.upload_button.Text = "Upload"
        Me.upload_button.UseVisualStyleBackColor = False
        '
        'Panel6
        '
        Me.Panel6.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Panel6.Controls.Add(Me.backup_button)
        Me.Panel6.Location = New System.Drawing.Point(402, 284)
        Me.Panel6.Name = "Panel6"
        Me.Panel6.Size = New System.Drawing.Size(236, 79)
        Me.Panel6.TabIndex = 12
        '
        'backup_button
        '
        Me.backup_button.BackColor = System.Drawing.Color.PaleVioletRed
        Me.backup_button.BackgroundImage = CType(resources.GetObject("backup_button.BackgroundImage"), System.Drawing.Image)
        Me.backup_button.Font = New System.Drawing.Font("Century Gothic", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.backup_button.ForeColor = System.Drawing.SystemColors.HighlightText
        Me.backup_button.Location = New System.Drawing.Point(31, 18)
        Me.backup_button.Name = "backup_button"
        Me.backup_button.Size = New System.Drawing.Size(183, 41)
        Me.backup_button.TabIndex = 6
        Me.backup_button.Text = "Backup"
        Me.backup_button.UseVisualStyleBackColor = False
        '
        'Main
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(708, 463)
        Me.Controls.Add(Me.Panel6)
        Me.Controls.Add(Me.Panel5)
        Me.Controls.Add(Me.Panel4)
        Me.Controls.Add(Me.Panel3)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Panel1)
        Me.DoubleBuffered = True
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
        Me.Name = "Main"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "HOME PAGE"
        Me.Panel1.ResumeLayout(False)
        Me.Panel2.ResumeLayout(False)
        Me.Panel3.ResumeLayout(False)
        Me.Panel4.ResumeLayout(False)
        Me.Panel5.ResumeLayout(False)
        Me.Panel6.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Panel1 As Panel
    Friend WithEvents Panel2 As Panel
    Friend WithEvents Panel3 As Panel
    Friend WithEvents Panel4 As Panel
    Friend WithEvents add_customers As Button
    Friend WithEvents view_subs As Button
    Friend WithEvents delete_customers As Button
    Friend WithEvents view_reviews As Button
    Friend WithEvents Panel5 As Panel
    Friend WithEvents upload_button As Button
    Friend WithEvents Panel6 As Panel
    Friend WithEvents backup_button As Button
End Class
